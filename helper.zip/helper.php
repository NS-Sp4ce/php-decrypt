<?php
/**
 * Tesseract
 * Author: Albert Zhan <albertzhan666@gmail.com>
 * Copyright (c) 2019-2019 The Albert Zhan
 */

namespace tesseract_ocr;
class Tesseract{

    /**
     * Setting additional parameters
     * @param string $name Parameter name
     * @param string $value parameter values
     * @return $this
     */
    public function setVariable($name,$value){

    }

    /**
     * Tesseract Initialization
     * @param string $dir Tessdata directory
     * @param string $lang Tessdata language pack
     * @param string $mod Engine mode
     * @return $this
     */
    public function init($dir,$lang,$mod='OEM_DEFAULT'){

    }

    /**
     * Setting Paging Mode
     * @param string $name Paging mode
     * @return $this
     */
    public function setPageSegMode($name){

    }

    /**
     * Setting Recognition Image
     * @param string $path Recognized Image Path
     * @return $this
     */
    public function setImage($path){

    }

    /**
     * Setting image recognition area
     * @param int $left Left
     * @param int $top Top
     * @param int $width Width
     * @param int $height Height
     * @return $this
     */
    public function setRectangle($left,$top,$width,$height){

    }

    /**
     * After Recognize, the output is kept internally until the next SetImage
     * @param int|null $monitor For the time being, only 0 or null is supported.
     * @return $this
     */
    public function recognize($monitor){
        //TODO ETEXT_DESC class is not supported for the time being
    }

    /**
     * Application Paging Layout
     * @return $this
     */
    public function analyseLayout(){

    }

    /**
     * Get page layout analysis
     * @param int $orientation      Page orientation
     * @param int $writingDirection Writing direction
     * @param int $textlineOrder    Textline order
     * @param float $deskewAngle      Inclination angle
     * @return $this
     */
    public function orientation(&$orientation,&$writingDirection,&$textlineOrder,&$deskewAngle){

    }

    /**
     * Search for text blocks
     * @param string $level             PageIteratorLevel
     * @param callable|string $callable PHP callback function
     */
    public function getComponentImages($level,$callable){

    }

    /**
     * Get result iterator
     * @param string $level             PageIteratorLevel
     * @param callable|string $callable PHP callback function
     */
    public function getIterator($level,$callable){

    }

    /**
     * Get UTF8 characters
     * @return string
     */
    public function getUTF8Text(){

    }

    /**
     * Free up recognition results and any stored image data
     */
    public function clear(){

    }

    /**
     * Get php tesseract version
     * @return string
     */
    public function version(){

    }

    /**
     * Get tesseract version
     * @return string
     */
    public function tesseract(){

    }

}